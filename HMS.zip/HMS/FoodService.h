#pragma once
#include<iostream>
using namespace std;
class FoodService
{
public:
	void ViewFoodMenu();
	void PlaceOrder();
	~FoodService(){}
	FoodService() = default;
	
};

